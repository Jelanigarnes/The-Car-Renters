﻿using CarRenterApp.Models;
using CarRenterApp.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarRenterApp.Repository
{
    public class VehicleRepository : IVehicle
    {
        private DB_Context db;
        public VehicleRepository(DB_Context _db)
        {
            db = _db;
        }
        public IEnumerable<Vehicle> GetVehicles => db.Vehicles;

        public void Add(Vehicle _Vehicle)
        {
            db.Vehicles.Add(_Vehicle);
            db.SaveChanges();
        }

        public Vehicle GetVehicle(int? ID)
        {
            Vehicle dbEntity = db.Vehicles.Find(ID);
            return dbEntity;
        }

        public void Remove(int? ID)
        {
            Vehicle dbEntity = db.Vehicles.Find(ID);
            db.Vehicles.Remove(dbEntity);
            db.SaveChanges();
        }
    }
}
