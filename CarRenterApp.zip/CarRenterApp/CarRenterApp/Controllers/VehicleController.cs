﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarRenterApp.Models;
using CarRenterApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace CarRenterApp.Controllers
{
    public class VehicleController : Controller
    {
        private readonly IVehicle _Vehicle;
        public VehicleController(IVehicle _IVehicle)
        {
            _Vehicle = _IVehicle;
        }
        public IActionResult Index()
        {
            return View(_Vehicle.GetVehicles);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Vehicle model)
        {
            if (ModelState.IsValid)
            {
                _Vehicle.Add(model);
                return RedirectToAction("Index");
            }
            return View(model);
        }
        public IActionResult Delete(int? ID)
        {
            if (ID == null)
            {
                
                return NotFound();
            }
            else
            {
                Vehicle model = _Vehicle.GetVehicle(ID);
                return View(model);
            }
        }
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirm(int? ID)
        {
            _Vehicle.Remove(ID);
            return RedirectToAction("Index");
        }
    }
}