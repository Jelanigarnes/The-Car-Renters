﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CarRenterApp.Models
{
    public enum Availability
    {
        Available,Rented,Unavailable
    }
    public class Vehicle
    {
        [Key]
        public int VehicleID { get; set; }
        [DisplayName("Vehicle Identification Number")]
        [Required(ErrorMessage = "VIN is Required.")]
        public int VIN { get; set; }
        [DisplayName("Vehicle Availability")]
        [Required(ErrorMessage = "Availability Status is Required.")]
        public Availability? Availability { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string Condition { get; set; }

    }
}
